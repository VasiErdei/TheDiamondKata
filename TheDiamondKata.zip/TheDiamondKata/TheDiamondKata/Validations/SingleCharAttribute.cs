﻿using System.ComponentModel.DataAnnotations;

public class SingleCharAttribute : ValidationAttribute
{
    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        if (value == null || !(value is string stringValue) || stringValue.Length != 1)
        {
            return new ValidationResult("Input must be a single character.");
        }

        return ValidationResult.Success;
    }
}
