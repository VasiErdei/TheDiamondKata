using Microsoft.AspNetCore.Mvc;
using TheDiamondKata.Application.Interfaces;
using TheDiamondKata.Domain.Exceptions;

namespace TheDiamondKata.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DiamondController : ControllerBase
    {
        private readonly ILogger<DiamondController> _logger;
        private readonly IDiamondGeneratorService _diamondGeneratorService;

        public DiamondController(ILogger<DiamondController> logger, IDiamondGeneratorService diamondGeneratorService)
        {
            _logger = logger;
            _diamondGeneratorService = diamondGeneratorService;
        }

        [HttpGet("{character}", Name = "GetDiamond")]
        public IActionResult Get([FromRoute][SingleChar] string character)
        {
            try
            {
                char inputChar = character[0];
                string diamond = _diamondGeneratorService.GenerateDiamond(inputChar);
                _logger.LogInformation(LogStrings.DiamondController.DiamondSuccessfullyCreated);

                return Ok(new { Diamond = diamond });
            }
            catch (DiamondGeneratorExceptions ex)
            {
                _logger.LogError(LogStrings.ExceptionMessage.DiamondGeneratorServiceError, ex.Message, ex.InnerException);

                return BadRequest(ex.Message);
            }
        }
    }
}
