﻿namespace TheDiamondKata.Domain.Exceptions
{
    public static class LogStrings
    {
        public static class ExceptionMessage
        {
            public const string DiamondGeneratorServiceCharacterMissing = "Input must be an alphabet character.";
            public const string DiamondGeneratorServiceError = "Unable to generate Diamond pattern. Error : {errorMessage} Inner Exception {innerExceptionMessage}";
        }

        public static class DiamondController
        {
            public const string DiamondSuccessfullyCreated = "Successfully generated Diamond.";
        }
    }
}
