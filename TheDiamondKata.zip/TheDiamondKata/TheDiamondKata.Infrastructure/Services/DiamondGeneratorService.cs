﻿using TheDiamondKata.Application.Interfaces;
using TheDiamondKata.Domain.Exceptions;

namespace TheDiamondKata.Infrastructure.Services
{
    public class DiamondGeneratorService : IDiamondGeneratorService
    {
        public string GenerateDiamond(char character)
        {
            if (!char.IsLetter(character))
            {
                throw new DiamondGeneratorExceptions(LogStrings.ExceptionMessage.DiamondGeneratorServiceCharacterMissing);
            }

            character = char.ToUpper(character);
            int size = character - 'A' + 1;
            int width = size * 2 - 1;

            char[,] diamondArray = CreateEmptyDiamondArray(width);
            FillDiamondArray(diamondArray, size);
            string diamond = ConvertDiamondArrayToString(diamondArray);

            return diamond;
        }

        private static char[,] CreateEmptyDiamondArray(int width)
        {
            char[,] diamondArray = new char[width, width];

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    diamondArray[i, j] = ' ';
                }
            }

            return diamondArray;
        }

        private static void FillDiamondArray(char[,] diamondArray, int size)
        {
            int mid = size - 1;

            for (int i = 0; i < size; i++)
            {
                char currentChar = (char)('A' + i);

                int left = mid - i;
                int right = mid + i;

                diamondArray[i, left] = currentChar;
                diamondArray[i, right] = currentChar;

                diamondArray[size * 2 - i - 2, left] = currentChar;
                diamondArray[size * 2 - i - 2, right] = currentChar;
            }
        }

        private string ConvertDiamondArrayToString(char[,] diamondArray)
        {
            int width = diamondArray.GetLength(0);
            char[] result = new char[width * (width + 1)];

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    result[i * (width + 1) + j] = diamondArray[i, j] == '\0' ? ' ' : diamondArray[i, j];
                }

                if (i < width - 1)
                {
                    result[i * (width + 1) + width] = '\n';
                }
            }

            string trimmedResult = new string(result).TrimEnd('\0');

            return trimmedResult;
        }
    }
}
