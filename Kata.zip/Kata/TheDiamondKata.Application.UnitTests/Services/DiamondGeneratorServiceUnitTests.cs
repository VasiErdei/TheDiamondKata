using TheDiamondKata.Application.Interfaces;
using TheDiamondKata.Application.Services;
using TheDiamondKata.Domain.Exceptions;

namespace TheDiamondKata.Application.UnitTests.Services
{
    [TestFixture]
    public class DiamondGeneratorServiceUnitTests
    {
        private IDiamondGeneratorService _diamondGeneratorService;

        [SetUp]
        public void Setup()
        {
            _diamondGeneratorService = new DiamondGeneratorService();
        }

        [Test]
        public void GenerateDiamond_ValidInput_ReturnsDiamondPattern()
        {
            // Arrange
            char character = 'C';
            string expectedDiamond = "  A  \n B B \nC   C\n B B \n  A  ";

            // Act
            string result = _diamondGeneratorService.GenerateDiamond(character);

            // Assert
            Assert.That(result, Is.EqualTo(expectedDiamond));
        }

        [Test]
        public void GenerateDiamond_InvalidInput_ThrowsArgumentException()
        {
            // Arrange
            char character = '1';

            // Act & Assert
            Assert.Throws<DiamondGeneratorExceptions>(() => _diamondGeneratorService.GenerateDiamond(character));
        }
    }
}
