﻿using TheDiamondKata.Application.Services;

namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var diamondGenerator = new DiamondGeneratorService();

            try
            {
                Console.WriteLine("Enter a character: ");
                char character = char.Parse(Console.ReadLine());

                string diamond = diamondGenerator.GenerateDiamond(character);
                Console.WriteLine("Diamond Pattern:");
                Console.WriteLine(diamond);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }
}