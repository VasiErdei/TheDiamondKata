﻿using System.Runtime.Serialization;

namespace TheDiamondKata.Domain.Exceptions
{
    [Serializable]
    public class DiamondGeneratorExceptions : Exception
    {
        public DiamondGeneratorExceptions() { }

        protected DiamondGeneratorExceptions(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public DiamondGeneratorExceptions(string? message) : base(message) { }

        public DiamondGeneratorExceptions(string? message, Exception? innerException) : base(message, innerException) { }
    }
}
