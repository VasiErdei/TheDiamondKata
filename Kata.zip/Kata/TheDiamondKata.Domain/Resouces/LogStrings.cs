﻿namespace TheDiamondKata.Domain.Exceptions
{
    public static class LogStrings
    {
        public static class ExceptionMessage
        {
            public const string DiamondGeneratorServiceCharacterMissing = "Input must be an alphabet character.";
        }
    }
}
