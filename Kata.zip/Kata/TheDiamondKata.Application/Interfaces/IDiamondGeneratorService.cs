﻿namespace TheDiamondKata.Application.Interfaces
{
    public interface IDiamondGeneratorService
    {
        public string GenerateDiamond(char character);
    }
}
